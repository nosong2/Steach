create table students
(
    id    int          not null
        primary key,
    name  varchar(30)  not null,
    email varchar(255) null,
    constraint email
        unique (email),
    constraint name
        unique (name),
    constraint FK_students_login_credentials
        foreign key (id) references login_credentials (id)
            on delete cascade
);

INSERT INTO s11p11d201.students (id, name, email) VALUES (101, 'NeoWave', 'neowave@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (102, '은하수Explorer', 'galaxyexplorer@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (103, 'StarDust', 'stardust@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (104, '빛의속도로', 'speedoflight@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (105, 'PixelNinja', 'pixelninja@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (106, 'CyberSeeker', 'cyberseeker@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (107, 'DreamCatcher', 'dreamcatcher@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (108, '밤의별빛', 'nightstarlight@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (109, 'DigitalNomad', 'digitalnomad@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (110, '솔바람', 'pinewind@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (111, 'EclipseHunter', 'eclipsehunter@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (112, 'ThunderBolt', 'thunderbolt@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (113, '푸른늑대', 'bluelupus@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (114, 'FireFrost', 'firefrost@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (115, 'GalaxyRider', 'galaxyrider@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (116, '별헤는밤', 'starnight@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (117, 'InfinityEdge', 'infinityedge@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (118, '고양이달', 'catmoon@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (119, 'CyberPhoenix', 'cyberphoenix@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (120, '하늘소리', 'skyvoice@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (121, 'LunarWave', 'lunarwave@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (122, 'TwilightEcho', 'twilightecho@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (123, '은빛바다', 'silversea@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (124, 'SkyWalker', 'skywalker@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (125, '블랙홀', 'blackhole@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (126, 'PixelBlaze', 'pixelblaze@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (127, 'DreamTraveler', 'dreamtraveler@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (128, '푸른바다', 'blueocean@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (129, 'SunsetChaser', 'sunsetchaser@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (130, 'StarGleam', 'stargleam@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (131, '나비효과', 'butterflyeffect@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (132, 'CyberWave', 'cyberwave@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (133, '별빛의춤', 'stardance@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (134, 'NightShade', 'nightshade@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (135, '푸른구름', 'bluecloud@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (136, 'GalaxyWhisper', 'galaxywhisper@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (137, '미래소년', 'futureboy@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (138, 'SolarWind', 'solarwind@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (139, '고요한밤', 'silentnight@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (140, 'FireFly', 'firefly@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (141, 'Blizzard', 'blizzard@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (142, 'StarBeam', 'starbeam@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (143, '새벽의노래', 'songofdawn@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (144, 'SkyRush', 'skyrush@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (145, 'CyberKnight', 'cyberknight@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (146, '별의속삭임', 'whisperofstars@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (147, 'LunarMist', 'lunarmist@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (148, '소나기', 'showerrain@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (149, 'FrostFire', 'frostfire@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (150, 'TwilightGleam', 'twilightgleam@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (151, '구름속에', 'insidecloud@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (152, 'CyberNinja', 'cyberninja@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (153, 'EternalFlame', 'eternalflame@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (154, '밤하늘의별', 'nightstars@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (155, 'IceBlade', 'iceblade@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (156, 'SolarEcho', 'solarecho@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (157, '푸른새벽', 'bluedawn@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (158, 'DigitalWave', 'digitalwave@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (159, '겨울바람', 'winterwind@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (160, 'LunarKnight', 'lunarknight@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (161, '신비로운별', 'mysticstar@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (162, 'PixelRush', 'pixelrush@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (163, '하늘의빛', 'skylight@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (164, 'DreamBlaze', 'dreamblaze@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (165, '구름의꿈', 'cloudsdream@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (166, 'CyberDreamer', 'cyberdreamer@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (167, '빛의여행자', 'traveleroflight@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (168, 'SilverMist', 'silvermise@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (169, 'MysticWave', 'mysticwave@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (170, '하늘길', 'skyroad@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (171, 'NebulaMist', 'nebulamist@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (172, '별빛속으로', 'intothestarlight@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (173, 'PixelStorm', 'pixelstorm@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (174, '밤의속삭임', 'whisperofnight@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (175, 'SkyBreeze', 'skybreeze@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (176, 'LunarRush', 'lunarrush@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (177, '신비의숲', 'mysticforest@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (178, 'DreamRush', 'dreamrush@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (179, '별빛의소리', 'voiceofstars@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (180, 'CyberSage', 'cybersage@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (181, 'TwilightMist', 'twilightmist@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (182, '은하수의꿈', 'dreamofmilkyway@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (183, 'CyberPulse', 'cyberpulse@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (184, '빛나는별', 'shiningstar@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (185, 'LunarLight', 'lunarlight@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (186, '밤의울림', 'echoofnight@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (187, 'SilverRush', 'silverrush@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (188, 'PixelEcho', 'pixeletso@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (189, '밤하늘의빛', 'lightofnight@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (190, 'CyberMystic', 'cybermystic@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (191, 'DreamEcho', 'dreamecho@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (192, '푸른별빛', 'bluestarlight@daum.net');
INSERT INTO s11p11d201.students (id, name, email) VALUES (193, 'MysticEdge', 'mysticedge@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (194, 'FireEcho', 'fireecho@yahoo.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (195, '별빛의속삭임', 'whisperofstarlight@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (196, 'CyberVision', 'cybervision@hotmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (197, '은하수의빛', 'lightofmilkyway@outlook.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (198, 'SkyDreamer', 'skydreamer@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (199, 'PixelVision', 'pixelvision@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (200, 'TwilightRush', 'twilightrush@protonmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3257, '주마루', 'studentlime1@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3267, 'student', 'student@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3287, '호두마루', 'studentlime2@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3384, '초코마루', 'studentlime3@gmail.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3389, '사과마루', 'studentlime4');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3398, '기모경', 'kmg@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3403, '동동마루', 'studentlime5');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3408, '피카츄', 'jo@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3409, '라이츄', 'sang@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3410, '이씨가문첫째아들', 'song@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3411, '꼬부기', 'kim@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3437, '버터풀', 'oiu12@naver.com');
INSERT INTO s11p11d201.students (id, name, email) VALUES (3475, '야도란', 'test@example.us1');
