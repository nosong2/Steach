create table students_curricula
(
    curriculum_id int not null,
    student_id    int not null,
    primary key (curriculum_id, student_id),
    constraint FK_students_curricula_curricula
        foreign key (curriculum_id) references curricula (id)
            on delete cascade,
    constraint FK_students_curricula_students
        foreign key (student_id) references students (id)
            on delete cascade
);

INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (999, 3267);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (999, 3398);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (999, 3408);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (999, 3409);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3267);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3398);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3408);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3410);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3411);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1030, 3437);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1036, 3257);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1036, 3287);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1036, 3384);
INSERT INTO s11p11d201.students_curricula (curriculum_id, student_id) VALUES (1036, 3403);
