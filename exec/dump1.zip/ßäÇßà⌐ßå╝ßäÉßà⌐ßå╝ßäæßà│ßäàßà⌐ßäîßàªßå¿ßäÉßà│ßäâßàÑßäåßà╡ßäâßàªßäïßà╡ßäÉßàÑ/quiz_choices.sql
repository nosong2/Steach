create table quiz_choices
(
    id              int auto_increment
        primary key,
    quiz_id         int          not null,
    is_answer       bit          not null,
    choice_sentence varchar(255) not null,
    constraint FK_quiz_choices_quizzes
        foreign key (quiz_id) references quizzes (id)
            on delete cascade
);

INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (545, 4559, true, 'O');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (546, 4559, false, 'X');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (547, 4559, false, 'O');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (548, 4559, false, 'O');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (549, 4560, true, '몰라');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (550, 4560, false, '내일');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (551, 4560, false, '모레');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (552, 4560, false, '몰라');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (553, 4561, true, '몰라');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (554, 4561, false, '내일');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (555, 4561, false, '모레');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (556, 4561, false, '몰라');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (689, 4611, true, '1');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (690, 4611, false, '0');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (691, 4611, false, '-1');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (692, 4611, false, '정답 없음.');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (693, 4612, false, '정답 없음.');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (694, 4612, false, '1');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (695, 4612, false, '10');
INSERT INTO s11p11d201.quiz_choices (id, quiz_id, is_answer, choice_sentence) VALUES (696, 4612, true, '-10');
