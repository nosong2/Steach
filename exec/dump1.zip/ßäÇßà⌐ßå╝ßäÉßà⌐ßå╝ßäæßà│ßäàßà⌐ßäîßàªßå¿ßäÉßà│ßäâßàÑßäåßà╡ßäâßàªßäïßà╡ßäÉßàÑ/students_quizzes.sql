create table students_quizzes
(
    student_id     int          not null,
    quiz_id        int          not null,
    score          int          not null,
    student_choice varchar(255) not null,
    primary key (student_id, quiz_id),
    constraint FK_students_quizzes_quizzes
        foreign key (quiz_id) references quizzes (id)
            on delete cascade,
    constraint FK_students_quizzes_students
        foreign key (student_id) references students (id)
            on delete cascade
);

INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3257, 4559, 100, 'O');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3257, 4560, 0, '내일');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3267, 4611, 80, '1');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3267, 4612, 80, '-10');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3287, 4559, 100, 'O');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3287, 4560, 0, '내일');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3287, 4561, 20, '몰라');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3384, 4559, 100, 'O');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3384, 4560, 80, '몰라');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3384, 4561, 100, '몰라');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3403, 4559, 100, 'O');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3403, 4560, 40, '몰라');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3403, 4561, 100, '몰라');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3408, 4611, 90, '1');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3408, 4612, 0, '10');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3410, 4611, 0, '0');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3410, 4612, 0, '10');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3411, 4611, 0, '0');
INSERT INTO s11p11d201.students_quizzes (student_id, quiz_id, score, student_choice) VALUES (3411, 4612, 80, '-10');
