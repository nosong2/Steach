create table classrooms
(
    lecture_id int          not null
        primary key,
    session_id varchar(255) not null,
    constraint FK_classrooms_lectures
        foreign key (lecture_id) references lectures (id)
            on delete cascade
);

INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (6602, 'Gyp2oWXFeD3Zj68OALFhsjtEnEs0rZjc0+sHzf3marU=');
INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (6862, 'zdLiz2WP6oXG5y7FMuUnRxnklLrcxqUz/RqdG0TXudA=');
INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (6863, 'YaKRe2ha6JDhCyvYoK5XDP/cMY3ML/IY6p5ncR5DVgE=');
INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (6864, 'vV0psQOQoBTyFUYnEkjiIBnklLrcxqUz/RqdG0TXudA=');
INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (6910, 'r+0nQeaFsrvnqn1Q9unEq9dXOCiozFfjGl1bizpWM2I=');
INSERT INTO s11p11d201.classrooms (lecture_id, session_id) VALUES (7203, 'gJEbP5znBuggYlm1NhGv9FFw9fAN2I23xJ2UXK3FC8E=');
