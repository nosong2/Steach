create table admins
(
    id   int         not null
        primary key,
    name varchar(30) not null,
    constraint name
        unique (name),
    constraint FK_admins_login_credentials
        foreign key (id) references login_credentials (id)
            on delete cascade
);

INSERT INTO s11p11d201.admins (id, name) VALUES (3268, 'admin');
