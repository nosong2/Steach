create table auth_codes
(
    auth_code     varchar(30)      not null
        primary key,
    is_registered bit default b'0' not null
);

INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('2ac2crwu6044brygtfhju6a2qxul6n', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('8mw10qbn3wqjxqirtlg80pdy5uasm7', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('a1q19kn02lgvxg6xw9690cuog1mz5o', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('depq4gqrm6lbai2rbdgkiqlheijlub', false);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('dhz9q334a2arxv70jusg3eu5tvawrf', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('ermjugmsh387g8qx2q7ip82ave6dcl', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('gl2d5wygstwfxx4iuesnuz07rwydfe', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('h3rw2olus45wo1xbrbbr83cjgco55a', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('i6z4hymz98yrwck068h607zomtoj4i', false);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('mjez7rd5bpbcytzq2hw0zy0ol8hmpt', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('nfr0kya2q89w4ndxqb5j0zcu5il9uw', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('p4gut5ghol9dy0qq8v9exr1xpmcqz7', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('t3yvmdhhrm7jr40hbb1lbzcg4ehwen', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('wg2m7fb7j6rvjifya8amw8et9wglsy', true);
INSERT INTO s11p11d201.auth_codes (auth_code, is_registered) VALUES ('yaiakws190t4g3r1bwj0peu9jibuin', true);
