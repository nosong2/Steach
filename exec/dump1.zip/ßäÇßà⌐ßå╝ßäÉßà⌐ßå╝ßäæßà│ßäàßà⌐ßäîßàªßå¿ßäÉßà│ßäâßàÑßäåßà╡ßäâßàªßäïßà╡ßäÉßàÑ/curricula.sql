create table curricula
(
    id                   int auto_increment
        primary key,
    teacher_id           int                                                                                                         null,
    title                varchar(255)                                                                                                not null,
    curriculum_detail_id int                                                                                                         null,
    created_at           datetime(6)                                                                                                 null,
    updated_at           datetime(6)                                                                                                 null,
    category             enum ('ARTS_AND_PHYSICAL', 'SOCIAL', 'ENGINEERING', 'ETC', 'FOREIGN_LANGUAGE', 'KOREAN', 'MATH', 'SCIENCE') null,
    constraint curriculum_detail_id
        unique (curriculum_detail_id),
    constraint FK_curricula_curriculum_detail
        foreign key (curriculum_detail_id) references curriculum_details (id)
            on delete cascade,
    constraint FK_curricula_teachers
        foreign key (teacher_id) references teachers (id)
            on delete set null
);

INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (999, 3266, '미적분 1 통합 강의', 999, '2024-08-12 03:05:49.140475', '2024-08-12 03:05:49.140475', 'KOREAN');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1030, 3270, '수학의 정석 완전 정복!!!!', 1030, '2024-08-12 10:03:18.568847', '2024-08-15 13:15:11.150056', 'MATH');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1036, 3256, '마루의 강아지교실', 1036, '2024-08-13 01:52:38.577199', '2024-08-15 06:12:23.564693', 'ETC');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1066, 3256, '주효림의 코딩교실', 1066, '2024-08-15 06:15:18.605764', '2024-08-15 06:15:18.605764', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1067, 3256, '중등 수학 교실', 1067, '2024-08-15 06:19:12.332319', '2024-08-15 06:19:12.332319', 'MATH');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1068, 3522, '중등 영어 교실', 1068, '2024-08-15 06:26:21.412346', '2024-08-15 06:26:21.412346', 'FOREIGN_LANGUAGE');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1069, 3522, '중등 문학 교실', 1069, '2024-08-15 06:32:02.519105', '2024-08-15 06:32:02.519105', 'KOREAN');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1070, 3523, '중등 한국사', 1070, '2024-08-15 06:46:53.076914', '2024-08-15 06:46:53.076914', 'SOCIAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1073, 1, '파이썬 프로그래밍 기초', 1073, '2024-08-15 10:15:16.577164', '2024-08-15 10:15:16.577164', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1074, 3270, '수학의 정석', 1074, '2024-08-15 11:01:54.960434', '2024-08-15 11:01:54.960434', 'MATH');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1075, 3270, '자바 자바스크립트 입문자 강의', 1075, '2024-08-15 11:04:55.867637', '2024-08-15 11:04:55.867637', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1076, 3270, '자바 입문자용 강의', 1076, '2024-08-15 11:10:39.577682', '2024-08-15 11:10:39.577682', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1077, 2, 'HTML/CSS 교실', 1077, '2024-08-15 11:13:43.520634', '2024-08-15 11:14:00.523915', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1078, 3270, '파이썬 입문자용 강의', 1078, '2024-08-15 11:14:03.892629', '2024-08-15 13:14:53.366456', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1079, 3, '디지털 문해력 교육', 1079, '2024-08-15 11:16:54.095239', '2024-08-15 11:16:54.095239', 'SOCIAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1081, 4, '프로그래밍 자료구조 수업', 1081, '2024-08-15 11:21:14.125565', '2024-08-15 11:21:14.125565', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1082, 5, '마인드스톰 EV3 로봇교실', 1082, '2024-08-15 11:24:14.271527', '2024-08-15 11:24:14.271527', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1083, 6, '인공지능 컴퓨팅 사고 수업', 1083, '2024-08-15 11:26:48.010380', '2024-08-15 11:26:48.010380', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1084, 3524, '수학 강의', 1084, '2024-08-15 11:34:05.525780', '2024-08-15 11:34:05.525780', 'MATH');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1085, 3524, '로봇공학 기초', 1085, '2024-08-15 11:36:27.066103', '2024-08-15 11:36:27.066103', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1087, 7, '중등 보안 교실', 1087, '2024-08-15 11:41:06.080212', '2024-08-15 11:41:06.080212', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1088, 3524, 'IT 윤리와 정보 보안의 중요성', 1088, '2024-08-15 11:46:12.982735', '2024-08-15 11:46:12.982735', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1089, 3524, '간단한 앱 개발', 1089, '2024-08-15 11:48:17.569943', '2024-08-15 11:48:17.569943', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1090, 3524, '게임 개발 기초', 1090, '2024-08-15 11:48:53.007169', '2024-08-15 11:48:53.007169', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1091, 3524, '인공지능 기초 개념', 1091, '2024-08-15 11:49:32.649203', '2024-08-15 11:49:32.649203', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1092, 8, '포토샵과 AI로 배우는 사진편집', 1092, '2024-08-15 11:54:14.554991', '2024-08-15 11:54:14.554991', 'ARTS_AND_PHYSICAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1093, 9, '프리미어+에펙의 정석', 1093, '2024-08-15 11:55:31.307136', '2024-08-15 11:55:31.307136', 'ARTS_AND_PHYSICAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1094, 10, 'SQL 교실', 1094, '2024-08-15 11:57:19.550458', '2024-08-15 11:57:19.550458', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1095, 11, '중학생을 위한 웹 보안 맛보기', 1095, '2024-08-15 12:02:35.330739', '2024-08-15 12:02:35.330739', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1096, 11, '인터넷의 역사', 1096, '2024-08-15 12:03:33.199104', '2024-08-15 12:03:33.199104', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1097, 13, '미래 직업과 IT 기술의 역할', 1097, '2024-08-15 12:31:38.112541', '2024-08-15 12:31:38.112541', 'SCIENCE');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1098, 13, '전자 공작 기초: 아두이노와 라즈베리 파이 실습', 1098, '2024-08-15 12:59:59.759278', '2024-08-15 12:59:59.759278', 'ENGINEERING');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1099, 17, '기초 경제학 개념: 수요와 공급의 원리', 1099, '2024-08-15 13:04:56.690224', '2024-08-15 13:04:56.690224', 'SOCIAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1101, 19, ' 인문학과 기술의 융합: 디지털 인문학 탐구', 1101, '2024-08-15 13:15:51.000013', '2024-08-15 13:15:51.000013', 'SOCIAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1102, 52, '간단한 애니메이션 제작: 애니메이트와 플래시', 1102, '2024-08-15 13:23:46.354123', '2024-08-15 13:23:46.354123', 'ARTS_AND_PHYSICAL');
INSERT INTO s11p11d201.curricula (id, teacher_id, title, curriculum_detail_id, created_at, updated_at, category) VALUES (1103, 22, '환경 보호와 기술의 역할 이해하기', 1103, '2024-08-15 13:31:25.665494', '2024-08-15 13:31:25.665494', 'SCIENCE');
