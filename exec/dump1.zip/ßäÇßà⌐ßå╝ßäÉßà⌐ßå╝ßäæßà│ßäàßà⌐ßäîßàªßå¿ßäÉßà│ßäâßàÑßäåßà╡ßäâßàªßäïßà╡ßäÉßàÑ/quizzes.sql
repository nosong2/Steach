create table quizzes
(
    id          int auto_increment
        primary key,
    lecture_id  int           not null,
    quiz_number tinyint       not null,
    question    varchar(255)  not null,
    time        int default 5 not null,
    constraint FK_quizzes_lectures
        foreign key (lecture_id) references lectures (id)
            on delete cascade
);

INSERT INTO s11p11d201.quizzes (id, lecture_id, quiz_number, question, time) VALUES (4559, 6910, 1, '목이 아프다?', 5);
INSERT INTO s11p11d201.quizzes (id, lecture_id, quiz_number, question, time) VALUES (4560, 6910, 2, '언제 나을까?', 5);
INSERT INTO s11p11d201.quizzes (id, lecture_id, quiz_number, question, time) VALUES (4561, 6910, 3, '언제 안아플까? (아프지마)', 5);
INSERT INTO s11p11d201.quizzes (id, lecture_id, quiz_number, question, time) VALUES (4611, 6862, 1, '1 나누기 1은 뭘까요?', 5);
INSERT INTO s11p11d201.quizzes (id, lecture_id, quiz_number, question, time) VALUES (4612, 6862, 2, '10 - 20 은 뭘까요?', 5);
