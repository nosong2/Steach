create table quiz_statistics
(
    id            int auto_increment
        primary key,
    student_id    int           not null,
    prev_rank     int default 0 null,
    prev_score    int default 0 null,
    current_rank  int default 0 null,
    current_score int default 0 null,
    lecture_id    int           not null
);

INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (13, 3257, 1, 170, 3, 230, 6576);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (38, 3287, 2, 180, 1, 260, 6576);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (177, 3384, 3, 180, 2, 280, 6576);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (184, 3389, 4, 0, 4, 0, 6576);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (203, 3287, 1, 100, 2, 120, 6910);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (204, 3257, 1, 100, 1, 100, 6910);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (205, 3384, 3, 180, 3, 280, 6910);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (206, 3403, 4, 140, 4, 240, 6910);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (255, 3287, 0, 0, 1, 100, 6577);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (256, 3384, 0, 0, 2, 80, 6577);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (257, 3287, 3, 0, 1, 80, 6578);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (258, 3257, 1, 80, 2, 80, 6578);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (259, 3384, 1, 80, 2, 160, 6578);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (260, 3257, 1, 160, 1, 260, 6579);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (261, 3287, 2, 100, 3, 100, 6579);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (262, 3384, 1, 160, 2, 160, 6579);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (263, 3384, 0, 0, 2, 80, 6580);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (264, 3287, 1, 380, 1, 480, 6581);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (265, 3287, 2, 380, 1, 460, 6582);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (272, 3384, 1, 300, 2, 400, 6582);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (315, 3287, 1, 80, 1, 160, 6580);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (316, 3437, 0, 0, 1, 80, 6980);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (317, 3287, 2, 60, 1, 160, 6980);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (324, 3287, 1, 160, 1, 240, 6583);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (331, 3287, 0, 0, 1, 80, 6584);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (332, 3437, 1, 80, 2, 80, 7091);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (333, 3398, 2, 0, 1, 0, 7091);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (346, 3287, 0, 67, 0, 67, 6585);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (347, 3257, 0, 67, 0, 67, 6585);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (390, 3411, 0, 80, 0, 160, 7212);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (391, 3408, 0, 0, 0, 0, 7212);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (392, 3409, 0, 60, 0, 140, 7212);
INSERT INTO s11p11d201.quiz_statistics (id, student_id, prev_rank, prev_score, current_rank, current_score, lecture_id) VALUES (393, 3410, 0, 40, 0, 100, 7212);
