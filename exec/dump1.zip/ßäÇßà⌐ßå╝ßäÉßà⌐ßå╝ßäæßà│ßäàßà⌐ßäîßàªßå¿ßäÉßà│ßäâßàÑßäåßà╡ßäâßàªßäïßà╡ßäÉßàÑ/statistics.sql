create table statistics
(
    student_id            int                                   not null
        primary key,
    gpt_career_suggestion varchar(255)  default '데이터가 더 필요합니다.' not null,
    average_focus_ratio1  decimal(5, 2) default 0.00            not null,
    lecture_count1        smallint      default 0               not null,
    sum_lecture_minutes1  int           default 0               not null,
    average_focus_ratio2  decimal(5, 2) default 0.00            not null,
    lecture_count2        smallint      default 0               not null,
    sum_lecture_minutes2  int           default 0               not null,
    average_focus_ratio3  decimal(5, 2) default 0.00            not null,
    lecture_count3        smallint      default 0               not null,
    sum_lecture_minutes3  int           default 0               not null,
    average_focus_ratio4  decimal(5, 2) default 0.00            not null,
    lecture_count4        smallint      default 0               not null,
    sum_lecture_minutes4  int           default 0               not null,
    average_focus_ratio5  decimal(5, 2) default 0.00            not null,
    lecture_count5        smallint      default 0               not null,
    sum_lecture_minutes5  int           default 0               not null,
    average_focus_ratio6  decimal(5, 2) default 0.00            not null,
    lecture_count6        smallint      default 0               not null,
    sum_lecture_minutes6  int           default 0               not null,
    average_focus_ratio7  decimal(5, 2) default 0.00            not null,
    lecture_count7        smallint      default 0               not null,
    sum_lecture_minutes7  int           default 0               not null,
    constraint FK_students_statistics_students
        foreign key (student_id) references students (id)
            on delete cascade
);

INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3257, '', 0.00, 2, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3267, '데이터가 더 필요합니다.', 12.38, 4, 100, 0.00, 0, 0, 70.00, 3, 200, 0.00, 0, 0, 70.00, 2, 100, 0.00, 0, 0, 0.00, 0, 0);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3287, '', 38.10, 2, 32, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3384, '', 4.38, 5, 100, 0.00, 0, 0, 50.00, 3, 200, 0.00, 0, 0, 0.00, 0, 0, 60.00, 2, 200, 30.00, 2, 150);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3389, '', 0.00, 1, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3398, '', 50.00, 1, 8, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0);
INSERT INTO s11p11d201.statistics (student_id, gpt_career_suggestion, average_focus_ratio1, lecture_count1, sum_lecture_minutes1, average_focus_ratio2, lecture_count2, sum_lecture_minutes2, average_focus_ratio3, lecture_count3, sum_lecture_minutes3, average_focus_ratio4, lecture_count4, sum_lecture_minutes4, average_focus_ratio5, lecture_count5, sum_lecture_minutes5, average_focus_ratio6, lecture_count6, sum_lecture_minutes6, average_focus_ratio7, lecture_count7, sum_lecture_minutes7) VALUES (3437, '', 43.75, 3, 7, 0.00, 0, 0, 0.00, 4, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0, 0.00, 0, 0);
