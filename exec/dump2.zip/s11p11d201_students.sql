-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `FK_students_login_credentials` FOREIGN KEY (`id`) REFERENCES `login_credentials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (101,'NeoWave','neowave@gmail.com'),(102,'은하수Explorer','galaxyexplorer@yahoo.com'),(103,'StarDust','stardust@naver.com'),(104,'빛의속도로','speedoflight@outlook.com'),(105,'PixelNinja','pixelninja@hotmail.com'),(106,'CyberSeeker','cyberseeker@daum.net'),(107,'DreamCatcher','dreamcatcher@gmail.com'),(108,'밤의별빛','nightstarlight@naver.com'),(109,'DigitalNomad','digitalnomad@yahoo.com'),(110,'솔바람','pinewind@outlook.com'),(111,'EclipseHunter','eclipsehunter@protonmail.com'),(112,'ThunderBolt','thunderbolt@naver.com'),(113,'푸른늑대','bluelupus@hotmail.com'),(114,'FireFrost','firefrost@daum.net'),(115,'GalaxyRider','galaxyrider@gmail.com'),(116,'별헤는밤','starnight@naver.com'),(117,'InfinityEdge','infinityedge@yahoo.com'),(118,'고양이달','catmoon@outlook.com'),(119,'CyberPhoenix','cyberphoenix@gmail.com'),(120,'하늘소리','skyvoice@naver.com'),(121,'LunarWave','lunarwave@outlook.com'),(122,'TwilightEcho','twilightecho@yahoo.com'),(123,'은빛바다','silversea@naver.com'),(124,'SkyWalker','skywalker@protonmail.com'),(125,'블랙홀','blackhole@gmail.com'),(126,'PixelBlaze','pixelblaze@daum.net'),(127,'DreamTraveler','dreamtraveler@naver.com'),(128,'푸른바다','blueocean@yahoo.com'),(129,'SunsetChaser','sunsetchaser@outlook.com'),(130,'StarGleam','stargleam@hotmail.com'),(131,'나비효과','butterflyeffect@gmail.com'),(132,'CyberWave','cyberwave@naver.com'),(133,'별빛의춤','stardance@daum.net'),(134,'NightShade','nightshade@protonmail.com'),(135,'푸른구름','bluecloud@yahoo.com'),(136,'GalaxyWhisper','galaxywhisper@gmail.com'),(137,'미래소년','futureboy@naver.com'),(138,'SolarWind','solarwind@hotmail.com'),(139,'고요한밤','silentnight@outlook.com'),(140,'FireFly','firefly@naver.com'),(141,'Blizzard','blizzard@gmail.com'),(142,'StarBeam','starbeam@daum.net'),(143,'새벽의노래','songofdawn@naver.com'),(144,'SkyRush','skyrush@outlook.com'),(145,'CyberKnight','cyberknight@hotmail.com'),(146,'별의속삭임','whisperofstars@gmail.com'),(147,'LunarMist','lunarmist@protonmail.com'),(148,'소나기','showerrain@yahoo.com'),(149,'FrostFire','frostfire@naver.com'),(150,'TwilightGleam','twilightgleam@gmail.com'),(151,'구름속에','insidecloud@daum.net'),(152,'CyberNinja','cyberninja@hotmail.com'),(153,'EternalFlame','eternalflame@outlook.com'),(154,'밤하늘의별','nightstars@naver.com'),(155,'IceBlade','iceblade@gmail.com'),(156,'SolarEcho','solarecho@protonmail.com'),(157,'푸른새벽','bluedawn@yahoo.com'),(158,'DigitalWave','digitalwave@naver.com'),(159,'겨울바람','winterwind@outlook.com'),(160,'LunarKnight','lunarknight@gmail.com'),(161,'신비로운별','mysticstar@naver.com'),(162,'PixelRush','pixelrush@hotmail.com'),(163,'하늘의빛','skylight@gmail.com'),(164,'DreamBlaze','dreamblaze@yahoo.com'),(165,'구름의꿈','cloudsdream@naver.com'),(166,'CyberDreamer','cyberdreamer@outlook.com'),(167,'빛의여행자','traveleroflight@gmail.com'),(168,'SilverMist','silvermise@naver.com'),(169,'MysticWave','mysticwave@hotmail.com'),(170,'하늘길','skyroad@yahoo.com'),(171,'NebulaMist','nebulamist@outlook.com'),(172,'별빛속으로','intothestarlight@protonmail.com'),(173,'PixelStorm','pixelstorm@gmail.com'),(174,'밤의속삭임','whisperofnight@naver.com'),(175,'SkyBreeze','skybreeze@yahoo.com'),(176,'LunarRush','lunarrush@outlook.com'),(177,'신비의숲','mysticforest@hotmail.com'),(178,'DreamRush','dreamrush@naver.com'),(179,'별빛의소리','voiceofstars@gmail.com'),(180,'CyberSage','cybersage@daum.net'),(181,'TwilightMist','twilightmist@yahoo.com'),(182,'은하수의꿈','dreamofmilkyway@naver.com'),(183,'CyberPulse','cyberpulse@protonmail.com'),(184,'빛나는별','shiningstar@outlook.com'),(185,'LunarLight','lunarlight@hotmail.com'),(186,'밤의울림','echoofnight@naver.com'),(187,'SilverRush','silverrush@gmail.com'),(188,'PixelEcho','pixeletso@yahoo.com'),(189,'밤하늘의빛','lightofnight@outlook.com'),(190,'CyberMystic','cybermystic@naver.com'),(191,'DreamEcho','dreamecho@gmail.com'),(192,'푸른별빛','bluestarlight@daum.net'),(193,'MysticEdge','mysticedge@protonmail.com'),(194,'FireEcho','fireecho@yahoo.com'),(195,'별빛의속삭임','whisperofstarlight@naver.com'),(196,'CyberVision','cybervision@hotmail.com'),(197,'은하수의빛','lightofmilkyway@outlook.com'),(198,'SkyDreamer','skydreamer@gmail.com'),(199,'PixelVision','pixelvision@naver.com'),(200,'TwilightRush','twilightrush@protonmail.com'),(3257,'주마루','studentlime1@gmail.com'),(3267,'student','student@naver.com'),(3287,'호두마루','studentlime2@gmail.com'),(3384,'초코마루','studentlime3@gmail.com'),(3389,'사과마루','studentlime4'),(3398,'기모경','kmg@naver.com'),(3403,'동동마루','studentlime5'),(3408,'피카츄','jo@naver.com'),(3409,'라이츄','sang@naver.com'),(3410,'이씨가문첫째아들','song@naver.com'),(3411,'꼬부기','kim@naver.com'),(3437,'버터풀','oiu12@naver.com'),(3475,'야도란','test@example.us1');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:43
