-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_codes`
--

DROP TABLE IF EXISTS `auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_codes` (
  `auth_code` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `is_registered` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`auth_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_codes`
--

LOCK TABLES `auth_codes` WRITE;
/*!40000 ALTER TABLE `auth_codes` DISABLE KEYS */;
INSERT INTO `auth_codes` VALUES ('2ac2crwu6044brygtfhju6a2qxul6n',_binary ''),('8mw10qbn3wqjxqirtlg80pdy5uasm7',_binary ''),('a1q19kn02lgvxg6xw9690cuog1mz5o',_binary ''),('depq4gqrm6lbai2rbdgkiqlheijlub',_binary '\0'),('dhz9q334a2arxv70jusg3eu5tvawrf',_binary ''),('ermjugmsh387g8qx2q7ip82ave6dcl',_binary ''),('gl2d5wygstwfxx4iuesnuz07rwydfe',_binary ''),('h3rw2olus45wo1xbrbbr83cjgco55a',_binary ''),('i6z4hymz98yrwck068h607zomtoj4i',_binary '\0'),('mjez7rd5bpbcytzq2hw0zy0ol8hmpt',_binary ''),('nfr0kya2q89w4ndxqb5j0zcu5il9uw',_binary ''),('p4gut5ghol9dy0qq8v9exr1xpmcqz7',_binary ''),('t3yvmdhhrm7jr40hbb1lbzcg4ehwen',_binary ''),('wg2m7fb7j6rvjifya8amw8et9wglsy',_binary ''),('yaiakws190t4g3r1bwj0peu9jibuin',_binary '');
/*!40000 ALTER TABLE `auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:37
