-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classrooms` (
  `lecture_id` int(11) NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`lecture_id`),
  CONSTRAINT `FK_classrooms_lectures` FOREIGN KEY (`lecture_id`) REFERENCES `lectures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classrooms`
--

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES (6576,'zTlwmrwFXFiF5NI9J4sB71D715LnxmXnvWhhl5C11Bk='),(6577,'8L07j2cdHN8yAOOUStpiCofXToz7Gdk9J27+CmU0HcI='),(6602,'Gyp2oWXFeD3Zj68OALFhsjtEnEs0rZjc0+sHzf3marU='),(6638,'/8sCtV1A8BK+/3kBEY61O2s7ePbvLDj4/HMwJ6HwZgI='),(6639,'X8FAJ9oZVnnRcLQvzkEMbR04T14O+uOge/LnHfLuJ1A='),(6640,'oJnmoF4sW1I1c1T6bvtgYtayhS7Kil/As1R5brDMyx4='),(6641,'QBlJ8dCzRpco164qRVGW54X4FNMdciNbARkLcLG+wAo='),(6679,'EsY18JTM1WhhNHQL4f/trfn+eTQsW20N9s+64E6ouhM='),(6680,'75ErjJxpdonIdRHZ3E0Sn4fy14GuTgn5o8fzD3tjXeE='),(6681,'dQTJ64VMPcKz0glEb/o2kelmmEwYq4Xt86Iog0atI6k='),(6862,'zdLiz2WP6oXG5y7FMuUnRxnklLrcxqUz/RqdG0TXudA='),(6863,'YaKRe2ha6JDhCyvYoK5XDP/cMY3ML/IY6p5ncR5DVgE='),(6864,'vV0psQOQoBTyFUYnEkjiIBnklLrcxqUz/RqdG0TXudA='),(6877,'lmxw3+MfGNXbY+mkzo/oKNayhS7Kil/As1R5brDMyx4='),(6910,'r+0nQeaFsrvnqn1Q9unEq9dXOCiozFfjGl1bizpWM2I='),(6980,'loyYAlfab+b/1ZNoDD4JePn+eTQsW20N9s+64E6ouhM='),(6981,'lPUkCeJ/+FLtmHpnqvuQkALQIk48wazfFrLbl6YJs8A='),(7091,'b5KaStDIjFkts6PKRXkwbOYsaBql/2kOj3Zg2pWO8WA='),(7092,'rNMDRdLWjHXM4FvzYBRR8oiCa1HuU0+w6V7U8ImZMz4='),(7203,'gJEbP5znBuggYlm1NhGv9FFw9fAN2I23xJ2UXK3FC8E=');
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:42
