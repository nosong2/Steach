-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lecture_id` int(11) NOT NULL,
  `quiz_number` tinyint(4) NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `time` int(11) NOT NULL DEFAULT 5,
  PRIMARY KEY (`id`),
  KEY `FK_quizzes_lectures` (`lecture_id`),
  CONSTRAINT `FK_quizzes_lectures` FOREIGN KEY (`lecture_id`) REFERENCES `lectures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4811 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quizzes`
--

LOCK TABLES `quizzes` WRITE;
/*!40000 ALTER TABLE `quizzes` DISABLE KEYS */;
INSERT INTO `quizzes` VALUES (4370,6576,1,'마루는 귀엽다?',5),(4371,6576,2,'마루는 굉장히 깜찍하다?',5),(4372,6576,3,'마루보다 춘식이가 귀엽다?',5),(4559,6910,1,'목이 아프다?',5),(4560,6910,2,'언제 나을까?',5),(4561,6910,3,'언제 안아플까? (아프지마)',5),(4610,6577,1,'코로나에 걸리면 귀가 아프다?',5),(4611,6862,1,'1 나누기 1은 뭘까요?',5),(4612,6862,2,'10 - 20 은 뭘까요?',5),(4613,6578,1,'string',5),(4614,6578,2,'string',5),(4615,6578,3,'string',5),(4616,6579,1,'string',5),(4617,6579,2,'string',5),(4618,6579,3,'string',5),(4649,6580,1,'string',5),(4650,6580,2,'string',5),(4651,6580,3,'string',5),(4652,6580,4,'string',5),(4653,6580,5,'string',5),(4654,6581,1,'string',5),(4655,6581,2,'string',5),(4656,6581,3,'string',5),(4657,6581,4,'string',5),(4658,6581,5,'string',5),(4659,6581,6,'string',5),(4660,6581,7,'string',5),(4661,6581,8,'string',5),(4662,6581,9,'string',5),(4663,6680,1,'123',5),(4665,6582,2,'초코마루가 제일 맛있다?',5),(4666,6582,3,'초코마루가 제일 맛있다?',5),(4667,6582,4,'초코마루가 제일 맛있다?',5),(4668,6582,5,'초코마루가 제일 맛있다?',5),(4669,6582,6,'초코마루가 제일 맛있다?',5),(4719,6980,1,'김헌규는 코로나인가?',5),(4720,6980,2,'이번 퀴즈',5),(4721,6980,4,'퀴즈',5),(4738,6583,1,'오늘 저녁은?',5),(4739,6583,2,'효림이는 금요일에 안와도 된다??',5),(4740,6583,3,'효림이는 사실 아직 아프다?? 아프다면 많이 아플까 적게 아플까? 목은 아플까?',5),(4741,6583,4,'효림이는 결석이 1번 남았다?',5),(4743,6584,4,'효림이는 결석이 1번 남았다? 8월밖에 안됐는데 벌써 결석을 2번이나 했다? 사실 결석 한 번은 이번달에 했다? 코로나걸려서 아파서 못온건데 억울하다아아아아아아아아아?',5),(4744,6584,4,'효림이는 결석이 1번 남았다? 8월밖에 안됐는데 벌써 결석을 2번이나 했다? 사실 결석 한 번은 이번달에 했다? ',5),(4745,6584,4,'효림이는 결석이 1번 남았다? 8월밖에 안됐는데 벌써 결석을 2번이나 했다? 사실 결석 한 번은 이번달에 했다? 코로나걸려서 아파서 못온건데 억울하다?',5),(4746,6584,4,'효림이는 결석이 1번 남았다? 8월밖에 안됐는데 벌써 결석을 2번이나 했다?',5),(4748,7091,1,'퀴즈1',5),(4749,7091,2,'퀴즈2',5),(4762,6585,1,'퀴즈1',3),(4763,6585,2,'퀴즈2',3),(4764,6585,3,'퀴즈3',3),(4771,6679,1,'퀴즈1',5),(4808,7212,1,'다음 중 UCC 편집을 위한 프로그램이 아닌 것은?',5),(4809,7212,2,'다음 중 UCC 촬영의 기본 요소로 옳은 것은?',5),(4810,7212,3,'다음 중 UCC를 촬영하기에 가장 적합한 휴대폰 기종은?',5);
/*!40000 ALTER TABLE `quizzes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:41
