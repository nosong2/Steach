-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_choices`
--

DROP TABLE IF EXISTS `quiz_choices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `is_answer` bit(1) NOT NULL,
  `choice_sentence` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_quiz_choices_quizzes` (`quiz_id`),
  CONSTRAINT `FK_quiz_choices_quizzes` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1270 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_choices`
--

LOCK TABLES `quiz_choices` WRITE;
/*!40000 ALTER TABLE `quiz_choices` DISABLE KEYS */;
INSERT INTO `quiz_choices` VALUES (37,4370,_binary '','확실하다'),(38,4370,_binary '\0','그런 것 같다'),(39,4370,_binary '\0','모르겠디'),(40,4370,_binary '\0','애매하다'),(41,4371,_binary '','확실하다'),(42,4371,_binary '\0','그런 것 같다'),(43,4371,_binary '\0','모르겠디'),(44,4371,_binary '\0','애매하다'),(45,4372,_binary '\0','확실하다'),(46,4372,_binary '','절대 아니다'),(47,4372,_binary '\0','모르겠디'),(48,4372,_binary '\0','애매하다'),(545,4559,_binary '','O'),(546,4559,_binary '\0','X'),(547,4559,_binary '\0','O'),(548,4559,_binary '\0','O'),(549,4560,_binary '','몰라'),(550,4560,_binary '\0','내일'),(551,4560,_binary '\0','모레'),(552,4560,_binary '\0','몰라'),(553,4561,_binary '','몰라'),(554,4561,_binary '\0','내일'),(555,4561,_binary '\0','모레'),(556,4561,_binary '\0','몰라'),(685,4610,_binary '','O'),(686,4610,_binary '\0','X'),(687,4610,_binary '\0','P'),(688,4610,_binary '\0','K'),(689,4611,_binary '','1'),(690,4611,_binary '\0','0'),(691,4611,_binary '\0','-1'),(692,4611,_binary '\0','정답 없음.'),(693,4612,_binary '\0','정답 없음.'),(694,4612,_binary '\0','1'),(695,4612,_binary '\0','10'),(696,4612,_binary '','-10'),(697,4613,_binary '','string'),(698,4613,_binary '\0','string'),(699,4613,_binary '\0','string'),(700,4613,_binary '\0','string'),(701,4614,_binary '','string'),(702,4614,_binary '\0','string'),(703,4614,_binary '\0','string'),(704,4614,_binary '\0','string'),(705,4615,_binary '','string'),(706,4615,_binary '\0','string'),(707,4615,_binary '\0','string'),(708,4615,_binary '\0','string'),(709,4616,_binary '','string'),(710,4616,_binary '\0','string'),(711,4616,_binary '\0','string'),(712,4616,_binary '\0','string'),(713,4617,_binary '','string'),(714,4617,_binary '\0','string'),(715,4617,_binary '\0','string'),(716,4617,_binary '\0','string'),(717,4618,_binary '','string'),(718,4618,_binary '\0','string'),(719,4618,_binary '\0','string'),(720,4618,_binary '\0','string'),(826,4649,_binary '','string'),(827,4650,_binary '','string'),(828,4651,_binary '','string'),(829,4652,_binary '','string'),(830,4653,_binary '','string'),(831,4654,_binary '','string'),(832,4655,_binary '','string'),(833,4656,_binary '','string'),(834,4657,_binary '','string'),(835,4658,_binary '','string'),(836,4659,_binary '','string'),(837,4660,_binary '','string'),(838,4661,_binary '','string'),(839,4662,_binary '','string'),(840,4663,_binary '\0','123'),(841,4663,_binary '','123'),(842,4663,_binary '\0','123'),(843,4663,_binary '\0','123'),(848,4665,_binary '','맞다'),(849,4665,_binary '\0','틀리다'),(850,4665,_binary '\0','모르겠다'),(851,4665,_binary '\0','아닌 것 같다'),(852,4666,_binary '','맞다'),(853,4666,_binary '\0','틀리다'),(854,4666,_binary '\0','모르겠다'),(855,4666,_binary '\0','아닌 것 같다'),(856,4667,_binary '','맞다'),(857,4667,_binary '\0','틀리다'),(858,4667,_binary '\0','모르겠다'),(859,4667,_binary '\0','아닌 것 같다'),(860,4668,_binary '','맞다'),(861,4668,_binary '\0','틀리다'),(862,4668,_binary '\0','모르겠다'),(863,4668,_binary '\0','아닌 것 같다'),(864,4669,_binary '','맞다'),(865,4669,_binary '\0','틀리다'),(866,4669,_binary '\0','모르겠다'),(867,4669,_binary '\0','아닌 것 같다'),(1000,4719,_binary '','맞다'),(1001,4719,_binary '\0','아니다'),(1002,4719,_binary '\0','맞는거같다'),(1003,4719,_binary '\0','모름'),(1004,4720,_binary '','ㅂㅇㅂㅇ'),(1005,4720,_binary '\0','ㅋㅋ'),(1006,4720,_binary '\0','ㅇㅇ'),(1007,4720,_binary '\0','ㄴㄴ'),(1008,4721,_binary '',''),(1009,4721,_binary '\0',''),(1010,4721,_binary '\0',''),(1011,4721,_binary '\0',''),(1054,4738,_binary '','대패 볶음밥'),(1055,4738,_binary '\0','떡볶이'),(1056,4738,_binary '\0','김찌'),(1057,4739,_binary '\0','맞다'),(1058,4739,_binary '','아니다 와야한다'),(1059,4740,_binary '','목도 아프고 많이 아프다'),(1060,4740,_binary '\0','목은 안아프지만 많이 아프다'),(1061,4740,_binary '\0','목도 안아프고 하나도 안아프다'),(1062,4740,_binary '\0','효림이는 쎄기때문에 사실 처음부터 하나도 안아팠다. 다 연기였다'),(1063,4741,_binary '','맞다'),(1064,4741,_binary '\0','아니다'),(1065,4741,_binary '\0','모르겠다'),(1070,4743,_binary '','맞다'),(1071,4743,_binary '\0','아니다'),(1072,4743,_binary '\0','모르겠다'),(1073,4743,_binary '\0','말이 너무 많다'),(1074,4744,_binary '','맞다'),(1075,4744,_binary '\0','아니다'),(1076,4744,_binary '\0','모르겠다'),(1077,4744,_binary '\0','말이 너무 많다'),(1078,4745,_binary '','맞다'),(1079,4745,_binary '\0','아니다'),(1080,4745,_binary '\0','모르겠다'),(1081,4745,_binary '\0','말이 너무 많다'),(1082,4746,_binary '','맞다'),(1083,4746,_binary '\0','아니다'),(1084,4746,_binary '\0','모르겠다'),(1085,4746,_binary '\0','말이 너무 많다'),(1090,4748,_binary '','ㅎㅇ'),(1091,4748,_binary '\0','ㅋㅋ'),(1092,4748,_binary '\0','ㅂㅇ'),(1093,4748,_binary '\0','ㅇㅇ'),(1094,4749,_binary '\0','ㅎㅇ'),(1095,4749,_binary '\0','ㄴㅁ'),(1096,4749,_binary '\0','ㄴㅁ'),(1097,4749,_binary '','ㅁㄴ'),(1130,4762,_binary '','string'),(1131,4762,_binary '\0','string'),(1132,4762,_binary '\0','string'),(1133,4762,_binary '\0','string'),(1134,4763,_binary '','string'),(1135,4763,_binary '\0','string'),(1136,4763,_binary '\0','string'),(1137,4763,_binary '\0','string'),(1138,4764,_binary '','string'),(1139,4764,_binary '\0','string'),(1140,4764,_binary '\0','string'),(1141,4764,_binary '\0','string'),(1158,4771,_binary '\0','qwe'),(1159,4771,_binary '','qwe'),(1160,4771,_binary '\0','qwe'),(1161,4771,_binary '\0','qwe'),(1258,4808,_binary '\0','Adobe Premiere Pro'),(1259,4808,_binary '\0','Final Cut Pro'),(1260,4808,_binary '','Video Destroy Pro'),(1261,4808,_binary '\0','iMovie'),(1262,4809,_binary '\0','우울한 마음가짐'),(1263,4809,_binary '','기획과 스토리 보드'),(1264,4809,_binary '\0','현란한 몸놀림'),(1265,4809,_binary '\0','거대한 힘'),(1266,4810,_binary '\0','아이폰 15 pro max'),(1267,4810,_binary '','삼성 갤럭시 S24 Ultra'),(1268,4810,_binary '\0','Xiaomi 13 Ultra'),(1269,4810,_binary '\0','Xperia 1 V');
/*!40000 ALTER TABLE `quiz_choices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:36
