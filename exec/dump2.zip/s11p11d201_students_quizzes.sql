-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p11d201
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students_quizzes`
--

DROP TABLE IF EXISTS `students_quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students_quizzes` (
  `student_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `student_choice` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`student_id`,`quiz_id`),
  KEY `FK_students_quizzes_quizzes` (`quiz_id`),
  CONSTRAINT `FK_students_quizzes_quizzes` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_students_quizzes_students` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students_quizzes`
--

LOCK TABLES `students_quizzes` WRITE;
/*!40000 ALTER TABLE `students_quizzes` DISABLE KEYS */;
INSERT INTO `students_quizzes` VALUES (3257,4370,90,'확실하다'),(3257,4371,80,'그런 것 같다'),(3257,4372,60,'절대 아니다'),(3257,4559,100,'O'),(3257,4560,0,'내일'),(3257,4613,80,'string'),(3257,4614,0,'string'),(3257,4616,60,'string'),(3257,4617,100,'string'),(3257,4618,100,'string'),(3257,4762,67,'string'),(3257,4764,0,'string'),(3267,4611,80,'1'),(3267,4612,80,'-10'),(3287,4370,80,'확실하다'),(3287,4371,100,'확실하다'),(3287,4372,80,'확실하다'),(3287,4559,100,'O'),(3287,4560,0,'내일'),(3287,4561,20,'몰라'),(3287,4610,100,'O'),(3287,4613,0,'string'),(3287,4614,0,'string'),(3287,4615,80,'string'),(3287,4616,100,'string'),(3287,4617,0,'string'),(3287,4618,0,'string'),(3287,4649,80,'string'),(3287,4651,80,'string'),(3287,4654,100,'string'),(3287,4657,80,'string'),(3287,4658,100,'string'),(3287,4660,100,'string'),(3287,4662,100,'string'),(3287,4665,100,'맞다'),(3287,4666,80,'맞다'),(3287,4667,100,'맞다'),(3287,4668,80,'맞다'),(3287,4669,100,'맞다'),(3287,4719,60,'맞다'),(3287,4720,100,'ㅂㅇㅂㅇ'),(3287,4740,80,'목도 아프고 많이 아프다'),(3287,4762,67,'string'),(3287,4763,0,'string'),(3384,4370,80,'확실하다'),(3384,4371,100,'확실하다'),(3384,4372,100,'절대 아니다'),(3384,4559,100,'O'),(3384,4560,80,'몰라'),(3384,4561,100,'몰라'),(3384,4610,80,'O'),(3384,4613,80,'string'),(3384,4614,0,'string'),(3384,4615,80,'string'),(3384,4616,60,'string'),(3384,4617,100,'string'),(3384,4618,0,'string'),(3384,4649,80,'string'),(3384,4665,0,'틀리다'),(3384,4666,100,'맞다'),(3384,4667,100,'맞다'),(3384,4668,100,'맞다'),(3384,4669,100,'맞다'),(3389,4370,0,'그런 것 같다'),(3389,4371,0,'모르겠디'),(3389,4372,0,'애매하다'),(3398,4748,0,'ㅋㅋ'),(3398,4749,0,'ㄴㅁ'),(3403,4559,100,'O'),(3403,4560,40,'몰라'),(3403,4561,100,'몰라'),(3408,4611,90,'1'),(3408,4612,0,'10'),(3408,4810,0,'Xiaomi 13 Ultra'),(3409,4810,80,'삼성 갤럭시 S24 Ultra'),(3410,4611,0,'0'),(3410,4612,0,'10'),(3410,4810,60,'삼성 갤럭시 S24 Ultra'),(3411,4611,0,'0'),(3411,4612,80,'-10'),(3411,4810,80,'삼성 갤럭시 S24 Ultra'),(3437,4719,80,'맞다'),(3437,4748,80,'ㅎㅇ'),(3437,4749,0,'ㄴㅁ');
/*!40000 ALTER TABLE `students_quizzes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:13:39
